"""Tests for the dice package"""

import dice.elements

dice.elements.Element.verbose = True
