from . import calculus
# XXX: hack to set methods
from . import approximation
from . import differentiation
from . import extrapolation
from . import polynomials
