Manifold for Geometric Algebra
==============================

.. module:: sympy.galgebra.manifold

Class Reference
---------------

.. autoclass:: Manifold
   :members:
