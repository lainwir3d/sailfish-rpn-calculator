.. _utilities-docs:

=========
Utilities
=========

.. TODO: add compilef.rst and benchmarking.rst when they're fixed

.. automodule:: sympy.utilities

Contents:

.. toctree::
   :maxdepth: 2

   autowrap.rst
   codegen.rst
   decorator.rst
   enumerative.rst
   iterables.rst
   lambdify.rst
   memoization.rst
   misc.rst
   pkgdata.rst
   pytest.rst
   randtest.rst
   runtests.rst
   source.rst
   timeutils.rst
