===================
High energy physics
===================

.. topic:: Abstract

   Contains docstrings for methods in high energy physics.

Gamma matrices
==============

.. toctree::
    :maxdepth: 3

    gamma_matrices.rst
