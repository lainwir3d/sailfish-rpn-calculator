====================================
Expression Manipulation (Docstrings)
====================================

msubs
=====

.. autofunction:: sympy.physics.mechanics.msubs

find_dynamicsymbols
===================

.. autofunction:: sympy.physics.mechanics.find_dynamicsymbols
