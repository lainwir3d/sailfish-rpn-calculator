======
Dagger
======

.. automodule:: sympy.physics.quantum.dagger
   :members:
