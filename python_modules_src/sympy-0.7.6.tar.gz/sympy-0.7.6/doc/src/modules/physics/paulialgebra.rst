=============
Pauli Algebra
=============

.. automodule:: sympy.physics.paulialgebra
   :members:
