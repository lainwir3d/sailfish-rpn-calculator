===============
Indexed Objects
===============

.. automodule:: sympy.tensor.indexed
   :members:
